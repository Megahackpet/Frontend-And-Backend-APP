<template>
  <div>
    <!--
    <nav>
      <router-link to="/">Home</router-link>
      <router-link to="/about">Acerca de</router-link>
    </nav>-->
    <router-view />
  </div>
</template>
<script>
export default{
  name: "App"
}
</script>